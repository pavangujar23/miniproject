const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const flash = require('connect-flash');
const passport = require('passport');
const session = require('express-session');
const methodOverride = require('method-override');
const exphbs = require('express-handlebars');
const app = express();

const PostRoute = require('./routes/posts');
const UsersRoute = require('./routes/users');

//import post schema------------
require('./Model/Post');
const Post = mongoose.model('posts')

//mongoose connect urls....

const remoteUrl ="mongodb+srv://hemanthgowda_02:hemanth02@cluster0-ep4lg.mongodb.net/test?retryWrites=true&w=majority"

//connect to mongodb
mongoose.connect(remoteUrl, {useNewUrlParser:true}, (err) => {
    if(err) throw err;
    console.log(`database connected`)
});

//load passportjs---
require('./config/passport')(passport);

//connect flash middleware
app.use(flash());

//express session middleware..
app.use(session({
    secret : 'keyboard cat',
    resave : false,
    saveUninitialized : true
    //cookie : {session : true}
}));
//passport session
app.use(passport.initialize());
app.use(passport.session());

//global var
app.use(function (req, res, next) {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.errors_msg = req.flash('errors_msg');
    res.locals.user = req.user || null;
    res.locals.error = req.flash('error');
    next();
})


//bodyparser middleware---------

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

//override with the X-HTTP-Method_Override header in the request
app.use(methodOverride('X-HTTP-Method-Overide'));

//override with POST having ?_method=DELETE/PUT
app.use(methodOverride('_method'))

//express handlebars middleware...........
app.engine('handlebars' , exphbs());
app.set('view engine' , 'handlebars');
//-----------------------------------

app.use(express.static(__dirname + '/public'));

app.get('' , (req, res) => {
    res.render('./index.handlebars');
});
app.get('/home' , (req, res) => {
    res.render('./index.handlebars');
});

app.use('/posts' , PostRoute);
app.use('/users', UsersRoute);

app.get('**' , (req, res) => {
    res.render('./posts/pagenotfound.handlebars');
});

// //create post get route
// app.get('/posts', (req, res) => {
//     res.render('./posts/addpost.handlebars');
// })

// app.get('/success',(req, res)=> {
//     Post.find({}).then(posts => {
        
//         res.render('./posts/success.handlebars',{
//             posts:posts
//         })
//     }).catch(err => console.log(err));
// });

// //post create method here

// app.post('/addpost' ,(req , res) => {
//     const errors = [];
//     if(!req.body.title){
//         errors.push({text : 'please add title'});
//     }
//     if(!req.body.details){
//         errors.push({text : 'please add details'});
//     }
//     if(errors.length>0){
//         res.render('./posts/addpost.handlebars', {
//         errors, 
//         title:req.body.title ,
//         details : req.body.details
//     })
//     }else{
//         const NewPost = {
//             title : req.body.title,
//             details : req.body.details
//         }
//         new Post(NewPost).save().then(post => {
//             req.flash('success_msg', 'successfully created');
//             res.redirect('/success')
//         })
//     }
// })

// //update post route here
// app.get('/edit/:id', (req, res) => {
//     Post.findOne({_id :req.params.id}).then(post => {
//     res.render('./posts/editpost.handlebars', {post:post})
// });
// });

// //delete with delete method--------
// app.delete('/delete/:id', (req, res) => {
//     Post.remove({_id : req.params.id}).then(() => {
//         res.redirect('/success');
//     })
// })

// //update with put method----
// app.put('/edit/:id', (req, res) =>{
//     Post.findOne({_id : req.params.id}).then(post => {
//         post.title = req.body.title;
//         post.details = req.body.details;

//         post.save().then(post => {
//             res.redirect('/success');
//         })
//     })
// })


const port = process.env.PORT || 3000;

app.listen(port, (err) => {
    if(err) throw err;
    console.log(`App is running in ${port}`);
})