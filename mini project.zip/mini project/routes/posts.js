const express = require('express');
const mongoose = require('mongoose');
const{ensureAuthenticated} = require ('../helpers/auth')
const router = express.Router();

//import post Schema
require('../Model/Post');
const  Post = mongoose.model('posts')



//create post get route
router.get('/addpost', ensureAuthenticated, (req, res) => {
    res.render('./posts/addpost.handlebars');
})


router.get('/', ensureAuthenticated, (req, res)=> {
    Post.find({}).then(posts => {
        
        res.render('./posts/success.handlebars',{
            posts:posts
        })
    }).catch(err => console.log(err));
});

//post create method here

router.post('/addpost' ,(req , res) => {
    const errors = [];
    if(!req.body.title){
        errors.push({text : 'please add title'});
    }
    if(!req.body.details){
        errors.push({text : 'please add details'});
    }
    if(errors.length>0){
        res.render('./posts/addpost.handlebars', {
        errors, 
        title:req.body.title ,
        details : req.body.details
    })
    }else{
        const NewPost = {
            title : req.body.title,
            details : req.body.details
        }
        new Post(NewPost).save().then(post => {
            req.flash('success_msg', 'successfully created');
            res.redirect('/posts')
        })
    }
})

//update post route here
router.get('/edit/:id', (req, res) => {
    Post.findOne({_id :req.params.id}).then(post => {
    res.render('./posts/editpost.handlebars', {post:post})
});
});

//delete with delete method--------
router.delete('/delete/:id', (req, res) => {
    Post.remove({_id : req.params.id}).then(() => {
        req.flash('success_msg', 'successfully deleted');
        res.redirect('/posts');
    })
})

//update with put method----
router.put('/edit/:id', (req, res) =>{
    Post.findOne({_id : req.params.id}).then(post => {
        post.title = req.body.title;
        post.details = req.body.details;

        post.save().then(post => {
            req.flash('success_msg', 'successfully updated');
            res.redirect('/posts');
        })
    })
})
router.get('**', (req, res) => {
    res.render('./posts/pagenotfound');
})

module.exports = router;