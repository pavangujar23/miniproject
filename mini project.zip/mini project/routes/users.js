const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const passport = require('passport');
const router = express.Router();

//load userschema
require('../Model/Users')
const User = mongoose.model('users');

//register routes here get methods
router.get('/register', (req, res) => {
    res.render('./users/register.handlebars');
});

//login routes here get methods
router.get('/login', (req, res) => {
    res.render('./users/login.handlebars');
});

//register post request--------
router.post('/register', (req,res) => {
    const errors = [];
    if(req.body.password != req.body.password2){
        errors.push({
            text : 'pasword do not match'
        })
    }
    if(req.body.password.length < 4){
        errors.push({
            text : 'pasword should be min 4 charcters'
        })
    }
    if(errors.length > 0){
        res.render('./users/register.handlebars',{
            errors : errors,
            username : req.body.username,
            email : req.body.email,
            password : req.body.password
        })
    }else {
        User.findOne({email : req.body.email}).then(user => {
            if(user){
                req.flash('errors_msg', `Email exists`);
                res.redirect('/users/register');
            }else {
                const newUsers = new User({
                   username : req.body.username,
                   email : req.body.email,
                   password : req.body.password 
                })
                bcrypt.genSalt(10, (err, salt) => {
                    bcrypt.hash(newUsers.password, salt, (err, hash) => {
                        newUsers.password = hash;
                        newUsers.save().then(user => {
                            req.flash('success_msg', 'successfully registered');
                            res.redirect('/users/login');
                        })
                    })
                })
            }
        
           
        }).catch(err => console.log(err));
    }
})

//login post.....
router.post('/login', (req, res, next) => {
    passport.authenticate('local',{
        successRedirect : '/posts',
        failureRedirect : '/users/login',
        failureFlash : true
    })(req, res, next)
})

//logout post-------
router.get('/logout', (req, res) => {
    req.logout();
    req.flash('success_msg', 'successfully logged out');
    res.redirect('/users/login');
});

module.exports = router;