module.exports = {
    ensureAuthenticated : (req, res, next) => {
        if(req.isAuthenticated()) {
            return next();
        }
        req.flash('errors_msg', 'you are not authorized');
        res.redirect('/users/login');
    }
}